def say_hello():
    """
    Print 'Hello, world!' to the console.
    """
    print("Hello, world from dev!")

